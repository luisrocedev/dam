<footer>
	<div class="contenedor">
		<div class="columna">
			<h3>Store</h3>
			<ul>
				<li>Mac</li>
				<li>iPad</li>
				<li>iPhone</li>
			</ul>
		</div>
	</div>
</footer>
