
<?php
	include "Classes/Bloque.php";
?>

<script>
	<?php include "bloque.js"?>
</script>
<style>
	<?php include "bloque.css"?>
</style>
