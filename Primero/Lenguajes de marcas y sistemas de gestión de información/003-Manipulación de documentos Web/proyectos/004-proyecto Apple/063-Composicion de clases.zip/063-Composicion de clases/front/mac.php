<!doctype html>
<html>
	<head>
		<title>Apple</title>
		<link rel="Stylesheet" href="estilo/general.css">
		<meta charset="utf-8">
	</head>
	<body>
		<?php include "modulos/cabecera/cabecera.php"; ?>
		<?php include "modulos/categoria/categoria.php"; ?>
		<?php include "modulos/piedepagina/piedepagina.php"; ?>
	</body>
</html>
