<main>
	
	<?php include "modulos/oferta/oferta.php" ?>
	<?php include "modulos/heroes/heroes.php" ?>
	<?php include "modulos/destacados/destacados.php" ?>
	<?php include "modulos/carrusel/carrusel.php" ?>
	<?php include "modulos/descargo/descargo.php" ?>
	
</main>
