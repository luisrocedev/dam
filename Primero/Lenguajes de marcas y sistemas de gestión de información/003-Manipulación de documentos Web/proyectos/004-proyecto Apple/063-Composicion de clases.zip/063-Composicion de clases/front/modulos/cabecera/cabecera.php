<header>
	<div class="contenedor">
		<img src="img/logo.svg">
		<nav>
			<ul>
				<template id="elementomenu">
					<li>
						<a href=""></a>
					</li>
				</template>
			</ul>
		</nav>
		<div id="supermenu">
			<div class="columna">
				<h3>Cabecera</h3>
				<ul>
					<li>Elemento</li>
					<li>Elemento</li>
					<li>Elemento</li>
					<li>Elemento</li>
					<li>Elemento</li>
				</ul>
			</div>
			<div class="columna">
				<h3>Cabecera</h3>
				<ul>
					<li>Elemento</li>
					<li>Elemento</li>
					<li>Elemento</li>
					<li>Elemento</li>
					<li>Elemento</li>
				</ul>
			</div>
			<div class="columna">
				<h3>Cabecera</h3>
				<ul>
					<li>Elemento</li>
					<li>Elemento</li>
					<li>Elemento</li>
					<li>Elemento</li>
					<li>Elemento</li>
				</ul>
			</div>
		</div>
	</div>
</header>
<script>
	<?php include "cabecera.js"?>
</script>
<style>
	<?php include "cabecera.css"?>
</style>
